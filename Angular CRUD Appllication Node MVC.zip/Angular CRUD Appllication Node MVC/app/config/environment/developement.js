module.exports ={
    port : "3000",
    databases:{
        mongodb:"mongodb://localhost/customers"
    }
};